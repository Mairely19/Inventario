export const initialProducts = [
  {
    id: 1,
    name: "Laptop HP",
    price: 1200,
    stock: 15
  },
  {
    id: 2,
    name: "Mouse Inalámbrico",
    price: 25,
    stock: 8
  }
];